export const FETCH_DATA: string = "main => FETCH_DATA";
