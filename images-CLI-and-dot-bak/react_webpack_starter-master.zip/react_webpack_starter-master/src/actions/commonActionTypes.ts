export const START: string = "_START";
export const STOP: string = "_STOP";
export const RESET: string = "_RESET";
export const SUCCESS: string = "_SUCCESS";
export const ERROR: string = "_ERROR";
